(()=>{document.body;var e=localStorage.getItem("theme");e&&document.documentElement.setAttribute("data-bs-theme",e)})();
