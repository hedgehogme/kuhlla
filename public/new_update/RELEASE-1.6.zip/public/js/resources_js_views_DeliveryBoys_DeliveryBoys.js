(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_views_DeliveryBoys_DeliveryBoys"],{

/***/ "./resources/js/views/DeliveryBoys/DeliveryBoys":
/*!******************************************************!*\
  !*** ./resources/js/views/DeliveryBoys/DeliveryBoys ***!
  \******************************************************/
/***/ (() => {



/***/ })

}]);